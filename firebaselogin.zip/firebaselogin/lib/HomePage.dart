// @dart=2.9

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // UserCredential user;
  // bool isSignedIn = false;

  // checkAuthentication() async {
  //   _auth.authStateChanges().listen((user) {
  //     if (user == null) {
  //       Navigator.pushReplacementNamed(context, '/SigninPage');
  //     }
  //   });
  // }

  // getUser() async {
  //   UserCredential firebaseUser = await _auth.currentUser();
  //   await firebaseUser?.reload();
  //   firebaseUser = await _auth.currentUser();

  //   if (firebaseUser != null) {
  //     setState(() {
  //       this.user = firebaseUser;
  //       this.isSignedIn = true;
  //     });
  //   }
  // }

  signOut() async {
    _auth.signOut();
  }

  // @override
  // void initState() {
  //   super.initState();
  //   this.checkAuthentication();
  //   this.getUser();
  // }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text('Home Page'),
      ),
    );
  }
}
